import tkinter as tk
from tkinter import ttk
from elementos import BotonText
from conectar import consultar_prestamos

def crearInterfazConsultasPrestamos(root):
    interfaz_consultas_prestamos = tk.Toplevel(root)
    interfaz_consultas_prestamos.geometry("1400x300") 
    interfaz_consultas_prestamos.resizable(False, False) 
    interfaz_consultas_prestamos.title("Consultas de prestamos")
    return interfaz_consultas_prestamos

def mostrarConsulta(interfaz_consultas_prestamos,menu_principal):
#Contenedor de todo
    canvas = tk.Canvas(interfaz_consultas_prestamos)
    canvas.pack(side="left", fill="both", expand=True)

    scrollbar = tk.Scrollbar(interfaz_consultas_prestamos, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    tittlebar = tk.Frame(canvas, bd=2, relief=tk.RAISED)
    tittlebar.pack(side=tk.TOP, fill=tk.X)
    labelTitulo = tk.Label(canvas, text="Consultas prestamos")
    labelTitulo.pack()

# Crear la tabla
    tabla = ttk.Treeview(canvas, columns=("Codigo cliente","Correo cliente", "ISBN", "N° Ejemplar", "Fecha prestamo", "Fecha limite", "Fecha entrega"))
    
    tabla.column("#0", width=5)  
    tabla.column("Codigo cliente", width=6)  
    tabla.column("Correo cliente", width=80)
    tabla.column("ISBN", width=100)
    tabla.column("N° Ejemplar", width=5)
    tabla.column("Fecha prestamo", width=5)
    tabla.column("Fecha limite", width=5)
    tabla.column("Fecha entrega", width=5)
    
    tabla.heading("#0", text="ID")
    tabla.heading("Codigo cliente", text="Codigo cliente")
    tabla.heading("Correo cliente", text="Correo cliente")
    tabla.heading("ISBN", text="ISBN")
    tabla.heading("N° Ejemplar", text="N° Ejemplar")
    tabla.heading("Fecha prestamo", text="Fecha prestamo")
    tabla.heading("Fecha limite", text="Fecha limite")
    tabla.heading("Fecha entrega", text="Fecha entrega")

# Obtener y mostrar los datos
    consultar_prestamos(tabla)
    tabla.pack(expand=True, fill="both")
    
    buttonCancelar = BotonText(canvas, "Salir", 6, command=lambda:cancelar(interfaz_consultas_prestamos,menu_principal))
    buttonCancelar.pack()

def accederInterfazConsultasPrestamos(root):
    interfaz_altas_prestamos = crearInterfazConsultasPrestamos(root)
    root.withdraw()
    mostrarConsulta(interfaz_altas_prestamos,root)

def cancelar(root, menu_principal):
    root.destroy()  # Destruye la ventana actual
    menu_principal.deiconify()  # Muestra la ventana del menú principal

if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("400x300") 
    root.title("Registro de profesores")
    accederInterfazConsultasPrestamos(root)
    root.mainloop()