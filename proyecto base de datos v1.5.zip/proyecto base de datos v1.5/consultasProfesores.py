import tkinter as tk
from tkinter import ttk, messagebox
from elementos import BotonText
from conectar import consultar_profesores,consultar_profesor_individual

def crearInterfazConsultasProfesores(root):
    interfaz_consultas_profesores = tk.Toplevel(root)
    interfaz_consultas_profesores.geometry("1400x300") 
    interfaz_consultas_profesores.resizable(False, False) 
    interfaz_consultas_profesores.title("Altas de profesores")
    return interfaz_consultas_profesores

def mostrarConsultaProfesores(interfaz_consultas_profesores,menu_principal):
#Contenedor de todo
    canvas = tk.Canvas(interfaz_consultas_profesores)
    canvas.pack(side="left", fill="both", expand=True)

    scrollbar = tk.Scrollbar(interfaz_consultas_profesores, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    tittlebar = tk.Frame(canvas, bd=2, relief=tk.RAISED)
    tittlebar.pack(side=tk.TOP, fill=tk.X)
    labelTitulo = tk.Label(canvas, text="Consultas profesor")
    labelTitulo.pack()

# Crear la tabla
    tabla = ttk.Treeview(canvas, columns=("Codigo","Nombre", "Carrera", "Correo", "Adeudo"))
    tabla.heading("#0", text="ID")
    tabla.heading("Codigo", text="Código")
    tabla.heading("Nombre", text="Nombre")
    tabla.heading("Carrera", text="Carrera")
    tabla.heading("Correo", text="Correo")
    tabla.heading("Adeudo", text="Adeudo")

# Obtener y mostrar los datos
    mostrar_datos(tabla)
    tabla.pack(expand=True, fill="both")
    
# Frame para el botón de búsqueda
    frame_busqueda = tk.Frame(canvas)
    frame_busqueda.pack(side="top", pady=(10, 0))

# Campo de entrada de texto para el código del alumno
    codigo_entry = tk.Entry(frame_busqueda)
    codigo_entry.pack(side="left")

# Botón para buscar alumno por código
    def buscar_profesor():
        codigo = codigo_entry.get()
        if codigo:
            consultar_profesor_individual(tabla, codigo)
        else:
            messagebox.showwarning("Error", "Por favor ingrese el código del profesor.")

    buscar_button = BotonText(frame_busqueda, "Buscar", 6, command=buscar_profesor)
    buscar_button.pack(side="left", padx=(10, 0))

# Botón para salir
    buttonCancelar = BotonText(frame_busqueda, "Salir", 6, command=lambda:cancelar(interfaz_consultas_profesores, menu_principal))
    buttonCancelar.pack(side="left", padx=(10, 0))

#Botón para refrescar la tabla
    buttonRefresh = BotonText(frame_busqueda, "Recargar", 6, command=lambda: mostrar_datos(tabla))
    buttonRefresh.pack(side="left", padx=(10, 0))

def mostrar_datos(tabla):
    tabla.delete(*tabla.get_children())  # Limpiar la tabla
    consultar_profesores(tabla)  # Pasar la tabla como argumento


def accederInterfazConsultasProfesores(root):
    interfaz_altas_profesores = crearInterfazConsultasProfesores(root)
    root.withdraw()
    mostrarConsultaProfesores(interfaz_altas_profesores,root)

def cancelar(root, menu_principal):
    root.destroy()  # Destruye la ventana actual
    menu_principal.deiconify()  # Muestra la ventana del menú principal


'''if __name__=="__main__":
    interfaz_consultas = tk.Tk()
    interfaz_consultas.geometry("1400x300") 
    interfaz_consultas.title("Altas de alumnos")

    mostrarConsulta(interfaz_consultas)
    interfaz_consultas.mainloop()'''