import tkinter as tk
from tkinter import ttk, messagebox
from elementos import BotonText
from conectar import consultar_libros, consultar_libros_individual

def crearInterfazConsultasLibros(root):
    interfaz_consultas_libros = tk.Toplevel(root)
    interfaz_consultas_libros.geometry("1400x300") 
    interfaz_consultas_libros.resizable(False, False) 
    interfaz_consultas_libros.title("Consultas de libros")
    return interfaz_consultas_libros

def mostrarConsulta(interfaz_consultas_libros,menu_principal):
#Contenedor de todo
    canvas = tk.Canvas(interfaz_consultas_libros)
    canvas.pack(side="left", fill="both", expand=True)

    scrollbar = tk.Scrollbar(interfaz_consultas_libros, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    tittlebar = tk.Frame(canvas, bd=2, relief=tk.RAISED)
    tittlebar.pack(side=tk.TOP, fill=tk.X)
    labelTitulo = tk.Label(canvas, text="Consultas libros")
    labelTitulo.pack()

# Crear la tabla
    tabla = ttk.Treeview(canvas, columns=("ISBN","Titulo", "Autor", "Editorial", "Año de publicacion", "Ejemplar", "Estado"))
    tabla.column("#0", width=5)  
    tabla.column("ISBN", width=100)  
    tabla.column("Titulo", width=150)
    tabla.column("Autor", width=100)
    tabla.column("Editorial", width=5)
    tabla.column("Año de publicacion", width=5)
    tabla.column("Ejemplar", width=5)
    tabla.column("Estado", width=5)
    
    tabla.heading("#0", text="ID")
    tabla.heading("ISBN", text="ISBN")
    tabla.heading("Titulo", text="Titulo")
    tabla.heading("Autor", text="Autor")
    tabla.heading("Editorial", text="Editorial")
    tabla.heading("Año de publicacion", text="Año de publicacion")
    tabla.heading("Ejemplar", text="Ejemplar")
    tabla.heading("Estado", text="Estado")

# Obtener y mostrar los datos
    mostrar_datos(tabla)
    tabla.pack(expand=True, fill="both")
    
# Frame para el botón de búsqueda
    frame_busqueda = tk.Frame(canvas)
    frame_busqueda.pack(side="top", pady=(10, 0))

# Campo de entrada de texto para el código del libro
    codigo_entry = tk.Entry(frame_busqueda)
    codigo_entry.pack(side="left")

# Botón para buscar libro por código
    def buscar_libro():
        codigo = codigo_entry.get()
        if codigo:
            consultar_libros_individual(tabla, codigo)
        else:
            messagebox.showwarning("Error", "Por favor ingrese el isbn del libro.")

    buscar_button = BotonText(frame_busqueda, "Buscar", 6, command=buscar_libro)
    buscar_button.pack(side="left", padx=(10, 0))

# Botón para salir
    buttonCancelar = BotonText(frame_busqueda, "Salir", 6, command=lambda:cancelar(interfaz_consultas_libros, menu_principal))
    buttonCancelar.pack(side="left", padx=(10, 0))

#Botón para refrescar la tabla
    buttonRefresh = BotonText(frame_busqueda, "Recargar", 6, command=lambda: mostrar_datos(tabla))
    buttonRefresh.pack(side="left", padx=(10, 0))

def mostrar_datos(tabla):
    tabla.delete(*tabla.get_children())  # Limpiar la tabla
    consultar_libros(tabla)  # Pasar la tabla como argumento


def accederInterfazConsultasLibros(root):
    interfaz_altas_libros = crearInterfazConsultasLibros(root)
    root.withdraw()
    mostrarConsulta(interfaz_altas_libros,root)

def cancelar(root, menu_principal):
    root.destroy()  # Destruye la ventana actual
    menu_principal.deiconify()  # Muestra la ventana del menú principal

'''if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("400x300") 
    root.title("Registro de profesores")
    accederInterfazConsultasLibros(root)
    root.mainloop()'''