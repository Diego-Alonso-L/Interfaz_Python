import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def create_pdf(file_name, nombreCliente, codigoCliente, isbnPrestado, numEjemplarPrestado, fechaPrestamo, fechaLimite):
    c = canvas.Canvas(file_name, pagesize=letter)
    c.drawString(100, 750, "Nombre: " + str(nombreCliente))
    c.drawString(100, 730, "Codigo: " + str(codigoCliente))
    c.drawString(100, 710, "ISBN.: " + str(isbnPrestado))
    c.drawString(100, 690, "Numero ejemplar: " + str(numEjemplarPrestado))
    c.drawString(100, 670, "Fecha del prestamo: " + str(fechaPrestamo))
    c.drawString(100, 650, "Fecha limite de entrega: " + str(fechaLimite))
    c.save()

def enviar_mensaje_fecha_limite(nombre_cliente,codigo_cliente,correo_cliente,isbn,ejemplar,fecha_prestamo,fecha_limite):
    # Variables
    recipient = correo_cliente
    subject = 'Fecha limite de entrega del libro prestado'
    body = 'Adjunto encontrará un PDF con información.'
    nombreCliente = nombre_cliente
    codigoCliente = codigo_cliente
    isbnPrestado = isbn
    numEjemplarPrestado = ejemplar
    fechaPrestamo = fecha_prestamo
    fechaLimite = fecha_limite
    pdf_file = 'fecha_limite.pdf'

    # Crear el archivo PDF
    create_pdf(pdf_file, nombreCliente, codigoCliente, isbnPrestado, numEjemplarPrestado, fechaPrestamo, fechaLimite)

    # Crear el mensaje de correo electrónico
    message = MIMEMultipart()
    message['From'] = 'Biblioteca Virtual'
    message['To'] = recipient
    message['Subject'] = subject

    # Cuerpo del mensaje
    message.attach(MIMEText(body, 'plain'))

    # Adjuntar el archivo PDF
    with open(pdf_file, 'rb') as attachment:
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename= {pdf_file}')
        message.attach(part)

    # Conectar al servidor SMTP y enviar el correo electrónico
    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login('bibliotecavirtualgratuitaudg@gmail.com', 'rret tyno ibrl ztro')
        server.send_message(message)
